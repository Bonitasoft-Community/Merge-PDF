package org.bonitasoft.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractBonitaSoftConnectorMergePDF extends
		AbstractConnector {

	protected final static String PDFNAME1_INPUT_PARAMETER = "pdfName1";
	protected final static String PDFNAME2_INPUT_PARAMETER = "pdfName2";
	protected final static String PROCESSINSTANCEID_INPUT_PARAMETER = "processInstanceId";
	protected final String OUTPUTPDFSTREAM_OUTPUT_PARAMETER = "outputPDFStream";

	protected final java.lang.String getPdfName1() {
		return (java.lang.String) getInputParameter(PDFNAME1_INPUT_PARAMETER);
	}

	protected final java.lang.String getPdfName2() {
		return (java.lang.String) getInputParameter(PDFNAME2_INPUT_PARAMETER);
	}

	protected final java.lang.Long getProcessInstanceId() {
		return (java.lang.Long) getInputParameter(PROCESSINSTANCEID_INPUT_PARAMETER);
	}

	protected final void setOutputPDFStream(
			org.bonitasoft.engine.bpm.document.DocumentValue outputPDFStream) {
		setOutputParameter(OUTPUTPDFSTREAM_OUTPUT_PARAMETER, outputPDFStream);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getPdfName1();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("pdfName1 type is invalid");
		}
		try {
			getPdfName2();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("pdfName2 type is invalid");
		}
		try {
			getProcessInstanceId();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"processInstanceId type is invalid");
		}

	}

}
